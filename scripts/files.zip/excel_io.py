"""
Ce fichier ne s'occupe que d'UNE chose : lire un fichier Excel
correctement. Il ne connaît rien à Region, Commune, Genre ou aux
règles métier -- c'est juste une boîte à outils générique, réutilisée
par geographie.py et references.py.
"""
import openpyxl


def ouvrir_plusieurs(chemins_excel: list[str]) -> dict:
    """
    Ouvre plusieurs fichiers Excel et retourne un dictionnaire
    {chemin: classeur_ouvert}, pour pouvoir ensuite chercher une feuille
    dans l'ensemble des fichiers fournis.
    """
    return {chemin: openpyxl.load_workbook(chemin) for chemin in chemins_excel}


def lister_feuilles(chemins_excel: list[str]):
    """Affiche les feuilles et en-têtes de chaque fichier -- outil de diagnostic."""
    for chemin in chemins_excel:
        classeur = openpyxl.load_workbook(chemin)
        print(f"\n=== {chemin} ===")
        for nom in classeur.sheetnames:
            feuille = classeur[nom]
            entetes = [c.value for c in feuille[1]] if feuille.max_row >= 1 else []
            print(f"  - '{nom}'  (en-têtes : {entetes})")


def demerger_feuille(feuille):
    """
    Une cellule fusionnée en Excel ne stocke sa valeur QUE dans la
    cellule en haut à gauche de la fusion -- les autres cellules qu'elle
    couvre sont réellement vides en interne. Cette fonction "défusionne"
    chaque plage et recopie la valeur dans toutes les cellules qu'elle
    couvrait, pour qu'une lecture ligne par ligne ne tombe plus sur des
    trous.
    """
    for plage in list(feuille.merged_cells.ranges):
        valeur = feuille.cell(row=plage.min_row, column=plage.min_col).value
        feuille.unmerge_cells(str(plage))
        for ligne in range(plage.min_row, plage.max_row + 1):
            for colonne in range(plage.min_col, plage.max_col + 1):
                feuille.cell(row=ligne, column=colonne).value = valeur


def trouver_feuille(classeurs: dict, nom_feuille: str):
    """
    Cherche une feuille par son nom dans l'ensemble des classeurs
    fournis (plusieurs fichiers Excel possibles). Retourne
    (chemin_du_fichier, feuille) du premier trouvé, ou (None, None) si
    absente partout.
    """
    trouvees = [
        (chemin, classeur[nom_feuille])
        for chemin, classeur in classeurs.items()
        if nom_feuille in classeur.sheetnames
    ]
    if not trouvees:
        return None, None
    if len(trouvees) > 1:
        fichiers = ", ".join(c for c, _ in trouvees)
        print(f"AVERTISSEMENT : la feuille '{nom_feuille}' existe dans "
              f"plusieurs fichiers ({fichiers}) -- utilisation du premier "
              f"trouvé ({trouvees[0][0]}).")
    return trouvees[0]


def lire_lignes(feuille, colonnes: dict) -> list[dict]:
    """
    Lit une feuille (déjà repérée et démergée) et retourne ses données
    sous forme de liste de dictionnaires simples.

    `colonnes` associe un nom de champ à un nom de colonne Excel, ex :
        {"nom": "nom_commune", "province": "nom_province"}
    -> chaque ligne retournée ressemble à :
        {"nom": "Nouna", "province": "Kossi"}

    La position de chaque colonne est retrouvée par son NOM (pas par un
    numéro fixe), donc l'ordre des colonnes dans le fichier n'a pas
    d'importance.
    """
    demerger_feuille(feuille)
    entetes = [cell.value for cell in feuille[1]]

    idx = {}
    for champ, nom_colonne in colonnes.items():
        if nom_colonne not in entetes:
            raise SystemExit(
                f"Colonne '{nom_colonne}' introuvable. En-têtes trouvés : {entetes}"
            )
        idx[champ] = entetes.index(nom_colonne)

    lignes = []
    for ligne in feuille.iter_rows(min_row=2, values_only=True):
        if all(v is None for v in ligne):
            continue  # ligne complètement vide, ignorée
        lignes.append({champ: ligne[i] for champ, i in idx.items()})
    return lignes
