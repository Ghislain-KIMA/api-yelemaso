"""
Ce fichier ne contient QUE les vocabulaires figés -- TypeCommune et
TypeMairie ne sont pas des données géographiques ouvertes, mais des
listes fixes définies dans le MCD. Leur position dans la liste (+1)
sert de pk, pour que geographie.py (qui résout Commune.type_commune) et
references.py (qui génère la table TypeCommune elle-même) restent
toujours d'accord sur les mêmes identifiants.
"""

TYPE_COMMUNE_LABELS = ["rurale", "urbaine", "statut particulier"]
TYPE_MAIRIE_LABELS = ["Centrale", "Arrondissement"]

VOCABULAIRES_FIXES = {
    "TYPE_COMMUNE_LABELS": TYPE_COMMUNE_LABELS,
    "TYPE_MAIRIE_LABELS": TYPE_MAIRIE_LABELS,
}


def resoudre(vocabulaire: list[str], valeur: str):
    """
    Cherche `valeur` dans `vocabulaire` (insensible à la casse) et
    retourne (label_canonique, pk) si trouvé, ou (None, None) sinon.
    Le pk est la position dans la liste, en commençant à 1.
    """
    if not valeur:
        return None, None
    correspondances = [v for v in vocabulaire if v.lower() == str(valeur).strip().lower()]
    if not correspondances:
        return None, None
    label_canonique = correspondances[0]
    pk = vocabulaire.index(label_canonique) + 1
    return label_canonique, pk
