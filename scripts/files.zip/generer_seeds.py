"""
C'EST CE FICHIER QUE TU EXÉCUTES. Il ne contient quasiment aucune
logique lui-même -- il se contente d'appeler les bons modules
(geographie.py ou references.py), qui font le vrai travail.

Usage :
    python generer_seeds.py geographie fichier1.xlsx fichier2.xlsx sortie.json
    python generer_seeds.py references fichier1.xlsx fichier2.xlsx sortie.json
    python generer_seeds.py geographie fichier1.xlsx --lister
"""
import json
import sys

import geographie
import references


def main():
    if len(sys.argv) < 4:
        print("Usage:")
        print("  python generer_seeds.py geographie fichier1.xlsx [...] sortie.json")
        print("  python generer_seeds.py references fichier1.xlsx [...] sortie.json")
        print("  python generer_seeds.py geographie fichier1.xlsx [...] --lister")
        sys.exit(1)

    type_seed = sys.argv[1]
    chemins_excel = sys.argv[2:-1]
    derniere_valeur = sys.argv[-1]

    if type_seed not in ("geographie", "references"):
        print(f"Type de seed inconnu : '{type_seed}' (attendu : geographie ou references)")
        sys.exit(1)

    import excel_io
    if derniere_valeur == "--lister":
        excel_io.lister_feuilles(chemins_excel)
        return

    chemin_json = derniere_valeur
    module = geographie if type_seed == "geographie" else references
    objets = module.construire_objets(chemins_excel)

    with open(chemin_json, "w", encoding="utf-8") as f:
        json.dump(objets, f, ensure_ascii=False, indent=2)
    print(f"\nTotal : {len(objets)} objets -> {chemin_json}")


if __name__ == "__main__":
    main()
