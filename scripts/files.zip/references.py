"""
Ce fichier ne s'occupe QUE des tables "plates" (juste id + label, sans
relation entre elles) : Type_Commune, Type_Mairie, Mode_Acces, Genre,
Type_Manifestation, Periodicite, Dimension, Type_Espace,
Statut_Demandeur, Ampliation.
"""
import uuid

import excel_io
import vocabulaires

# (nom_feuille_excel, "app.modele", nom_colonne_label, type_pk)
TABLES = [
    ("Type_Commune", "administration.typecommune", "label", "fixe:TYPE_COMMUNE_LABELS"),
    ("Type_Mairie", "administration.typemairie", "label", "fixe:TYPE_MAIRIE_LABELS"),
    ("Mode_Acces", "culture.modeacces", "label", "int"),
    ("Genre", "culture.genre", "label", "int"),
    ("Type_Manifestation", "culture.typemanifestation", "label", "int"),
    ("Periodicite", "culture.periodicite", "label", "int"),
    ("Dimension", "culture.dimension", "label", "int"),
    ("Type_Espace", "culture.typeespace", "label", "int"),
    ("Statut_Demandeur", "gestion.statutdemandeur", "label", "int"),
    ("Ampliation", "gestion.ampliation", "label", "uuid"),
]


def construire_objets_pour_une_table(feuille, modele: str, nom_colonne: str, type_pk: str) -> list[dict]:
    """
    Traite UNE seule feuille/table à la fois. Séparée de la boucle
    principale pour rester lisible : ici, on ne s'occupe que de calculer
    le bon pk pour chaque ligne, selon le type attendu.
    """
    lignes = excel_io.lire_lignes(feuille, {"label": nom_colonne})

    objets = []
    labels_vus = set()
    compteur = 0
    vocabulaire_fixe = None
    if type_pk.startswith("fixe:"):
        vocabulaire_fixe = vocabulaires.VOCABULAIRES_FIXES[type_pk.split(":", 1)[1]]

    for ligne in lignes:
        label = ligne["label"]
        if not label:
            continue
        label = str(label).strip()
        if label in labels_vus:
            continue

        if vocabulaire_fixe is not None:
            label_canonique, pk = vocabulaires.resoudre(vocabulaire_fixe, label)
            if pk is None:
                print(f"AVERTISSEMENT : '{label}' ne correspond à aucune "
                      f"valeur attendue ({vocabulaire_fixe}) -- ignoré.")
                continue
            label = label_canonique
        elif type_pk == "uuid":
            compteur += 1
            pk = str(uuid.uuid4())
        else:
            compteur += 1
            pk = compteur

        labels_vus.add(label)
        objets.append({"model": modele, "pk": pk, "fields": {"label": label}})

    return objets


def construire_objets(chemins_excel: list[str]) -> list[dict]:
    """Fonction principale : parcourt TABLES et assemble tous les objets."""
    classeurs = excel_io.ouvrir_plusieurs(chemins_excel)
    objets = []

    for nom_feuille, modele, nom_colonne, type_pk in TABLES:
        chemin, feuille = excel_io.trouver_feuille(classeurs, nom_feuille)
        if feuille is None:
            print(f"AVERTISSEMENT : feuille '{nom_feuille}' absente -- "
                  f"table '{modele}' non alimentée.")
            continue

        objets_table = construire_objets_pour_une_table(feuille, modele, nom_colonne, type_pk)
        objets.extend(objets_table)
        print(f"{nom_feuille} -> {modele} : {len(objets_table)} valeurs")

    return objets
