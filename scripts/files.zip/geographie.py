"""
Ce fichier ne s'occupe QUE de la logique métier propre à la hiérarchie
géographique : quelles feuilles/colonnes chercher, et comment résoudre
les clés étrangères (Province -> Region, Commune -> Province,
Commune -> TypeCommune).

Il s'appuie sur excel_io.py pour la lecture, et vocabulaires.py pour
TypeCommune -- il ne réimplémente aucune de ces deux briques.
"""
import excel_io
import vocabulaires

NOMS_FEUILLES = {
    "region": "Region",
    "province": "Province",
    "commune": "Commune",
}

COLONNES = {
    "region": {"nom": "nom_region"},
    "province": {"nom": "nom_province", "region": "nom_region"},
    "commune": {"nom": "nom_commune", "province": "nom_province", "type_commune": "type_commune"},
}


def lire_table(classeurs: dict, cle: str) -> list[dict]:
    """Repère la feuille correspondant à `cle` et en lit les lignes."""
    nom_feuille = NOMS_FEUILLES[cle]
    chemin, feuille = excel_io.trouver_feuille(classeurs, nom_feuille)
    if feuille is None:
        raise SystemExit(
            f"Feuille '{nom_feuille}' introuvable dans les fichiers fournis. "
            f"Lance avec --lister pour voir les noms disponibles."
        )
    return excel_io.lire_lignes(feuille, COLONNES[cle])


def construire_objets(chemins_excel: list[str]) -> list[dict]:
    """
    Fonction principale de ce module : lit les 3 feuilles et retourne
    la liste d'objets prête à écrire en JSON, avec toutes les clés
    étrangères résolues.
    """
    classeurs = excel_io.ouvrir_plusieurs(chemins_excel)

    lignes_region = lire_table(classeurs, "region")
    lignes_province = lire_table(classeurs, "province")
    lignes_commune = lire_table(classeurs, "commune")

    objets = []
    regions = {}    # nom -> pk
    provinces = {}  # nom -> pk

    for ligne in lignes_region:
        nom = ligne["nom"]
        if not nom or nom in regions:
            continue
        regions[nom] = len(regions) + 1
        objets.append({
            "model": "administration.region",
            "pk": regions[nom],
            "fields": {"nom_region": nom},
        })

    for ligne in lignes_province:
        nom = ligne["nom"]
        nom_region = ligne["region"]
        if not nom or nom in provinces:
            continue
        if nom_region not in regions:
            print(f"AVERTISSEMENT : région '{nom_region}' inconnue pour la province '{nom}'.")
            continue
        provinces[nom] = len(provinces) + 1
        objets.append({
            "model": "administration.province",
            "pk": provinces[nom],
            "fields": {"nom_province": nom, "region": regions[nom_region]},
        })

    pk_commune = 0
    for ligne in lignes_commune:
        nom = ligne["nom"]
        nom_province = ligne["province"]
        if not nom:
            continue
        if nom_province not in provinces:
            print(f"AVERTISSEMENT : province '{nom_province}' inconnue pour la commune '{nom}'.")
            continue
        pk_commune += 1

        _, type_commune_pk = vocabulaires.resoudre(
            vocabulaires.TYPE_COMMUNE_LABELS, ligne.get("type_commune")
        )
        if ligne.get("type_commune") and type_commune_pk is None:
            print(f"AVERTISSEMENT : type_commune '{ligne['type_commune']}' "
                  f"(commune '{nom}') non reconnu -- laissé vide.")

        objets.append({
            "model": "administration.commune",
            "pk": pk_commune,
            "fields": {
                "nom_commune": nom,
                "province": provinces[nom_province],
                "type_commune": type_commune_pk,
            },
        })

    print(f"{len(regions)} régions, {len(provinces)} provinces, {pk_commune} communes")
    return objets
