-- ============================================================================
-- SCHEMA SQLITE - Base locale d'un poste de travail (Desktop)
-- Version alignee sur le MPD final (33 tables cote central)
-- ============================================================================
-- A executer sur CHAQUE connexion : PRAGMA foreign_keys = ON;
--
-- Convention de types : SMALLINT->INTEGER, UUID->TEXT, DATE/DATETIME->TEXT (ISO 8601)
-- Convention de synchronisation (tables PRODUITES localement uniquement) :
--   sync_status ('pending'|'synced'|'error'), local_created_at, local_updated_at
-- ============================================================================

PRAGMA foreign_keys = ON;

-- ============================================================================
-- TABLES DE REFERENCE (lecture seule -- synchronisees depuis le central)
-- ============================================================================

CREATE TABLE region (
    id          INTEGER PRIMARY KEY,
    nom_region  TEXT NOT NULL
);

CREATE TABLE province (
    id            INTEGER PRIMARY KEY,
    nom_province  TEXT NOT NULL,
    region_id     INTEGER NOT NULL REFERENCES region(id)
);

CREATE TABLE type_commune (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

CREATE TABLE commune (
    id                 INTEGER PRIMARY KEY,
    nom_commune        TEXT NOT NULL,
    type_commune_id    INTEGER NOT NULL REFERENCES type_commune(id),
    province_id        INTEGER NOT NULL REFERENCES province(id)
);

CREATE TABLE type_mairie (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

CREATE TABLE mairie (
    id               INTEGER PRIMARY KEY,
    nom_mairie       TEXT NOT NULL,
    type_mairie_id   INTEGER NOT NULL REFERENCES type_mairie(id),
    commune_id       INTEGER NOT NULL REFERENCES commune(id)
);

CREATE TABLE statut_demandeur (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

CREATE TABLE mode_acces (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

CREATE TABLE genre (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

CREATE TABLE periodicite (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

CREATE TABLE type_manifestation (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

CREATE TABLE dimension (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

CREATE TABLE type_espace (
    id     INTEGER PRIMARY KEY,
    label  TEXT NOT NULL
);

-- ============================================================================
-- POSTE -- une seule ligne : auto-enregistrement local, sync ascendante
-- ============================================================================

CREATE TABLE poste (
    id          TEXT PRIMARY KEY,
    structure   TEXT NOT NULL,
    telephone   TEXT,
    email       TEXT,
    login_at    TEXT,
    created_at  TEXT NOT NULL,
    updated_at  TEXT,
    deleted_at  TEXT,
    mairie_id   INTEGER NOT NULL REFERENCES mairie(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================================
-- TABLES PRODUITES LOCALEMENT (lecture/ecriture, avec suivi de synchronisation)
-- ============================================================================

CREATE TABLE cnib (
    id         TEXT PRIMARY KEY,
    numero     TEXT NOT NULL,
    date_cnib  TEXT NOT NULL,
    structure  TEXT NOT NULL,
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE demandeur (
    id                    TEXT PRIMARY KEY,
    nom                   TEXT NOT NULL,
    prenom                TEXT NOT NULL,
    telephone             TEXT NOT NULL,
    email                 TEXT,
    profession            TEXT NOT NULL,
    residence             TEXT NOT NULL,
    cnib_id               TEXT NOT NULL UNIQUE REFERENCES cnib(id),
    -- Nullable : en attente de classement si "Autre" a ete choisi
    statut_demandeur_id   INTEGER REFERENCES statut_demandeur(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE statut_demandeur_autre (
    id                    TEXT PRIMARY KEY,
    label                 TEXT NOT NULL,
    datetime_proposition  TEXT NOT NULL,
    statut                TEXT NOT NULL DEFAULT 'en_attente',
    demandeur_id          TEXT NOT NULL REFERENCES demandeur(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE demande (
    id             TEXT PRIMARY KEY,
    date_demande   TEXT NOT NULL,
    objet          TEXT NOT NULL,
    demandeur_id   TEXT NOT NULL REFERENCES demandeur(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE manifestation (
    id                      TEXT PRIMARY KEY,
    espace                  TEXT NOT NULL,
    duree                   INTEGER,
    datetime_debut          TEXT NOT NULL,
    datetime_fin            TEXT,
    mode_acces_id           INTEGER NOT NULL REFERENCES mode_acces(id),
    -- Nullable : en attente de classement si "Autre" a ete choisi
    genre_id                INTEGER REFERENCES genre(id),
    periodicite_id          INTEGER REFERENCES periodicite(id),
    type_manifestation_id   INTEGER REFERENCES type_manifestation(id),
    dimension_id            INTEGER REFERENCES dimension(id),
    type_espace_id          INTEGER REFERENCES type_espace(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE demande_manifestation (
    demande_id        TEXT NOT NULL REFERENCES demande(id),
    manifestation_id  TEXT NOT NULL REFERENCES manifestation(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (demande_id, manifestation_id)
);

-- Tables "_Autre" liees a Manifestation (meme principe que statut_demandeur_autre)
CREATE TABLE genre_autre (
    id                    TEXT PRIMARY KEY,
    label                 TEXT NOT NULL,
    datetime_proposition  TEXT NOT NULL,
    statut                TEXT NOT NULL DEFAULT 'en_attente',
    manifestation_id      TEXT NOT NULL REFERENCES manifestation(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE type_manifestation_autre (
    id                    TEXT PRIMARY KEY,
    label                 TEXT NOT NULL,
    datetime_proposition  TEXT NOT NULL,
    statut                TEXT NOT NULL DEFAULT 'en_attente',
    manifestation_id      TEXT NOT NULL REFERENCES manifestation(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE periodicite_autre (
    id                    TEXT PRIMARY KEY,
    label                 TEXT NOT NULL,
    datetime_proposition  TEXT NOT NULL,
    statut                TEXT NOT NULL DEFAULT 'en_attente',
    manifestation_id      TEXT NOT NULL REFERENCES manifestation(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE dimension_autre (
    id                    TEXT PRIMARY KEY,
    label                 TEXT NOT NULL,
    datetime_proposition  TEXT NOT NULL,
    statut                TEXT NOT NULL DEFAULT 'en_attente',
    manifestation_id      TEXT NOT NULL REFERENCES manifestation(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE type_espace_autre (
    id                    TEXT PRIMARY KEY,
    label                 TEXT NOT NULL,
    datetime_proposition  TEXT NOT NULL,
    statut                TEXT NOT NULL DEFAULT 'en_attente',
    manifestation_id      TEXT NOT NULL REFERENCES manifestation(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE autorisation (
    id                  TEXT PRIMARY KEY,
    numero              TEXT NOT NULL,
    date_autorisation   TEXT NOT NULL,
    mairie_id           INTEGER NOT NULL REFERENCES mairie(id),
    demande_id          TEXT NOT NULL REFERENCES demande(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE personne (
    id          TEXT PRIMARY KEY,
    nom         TEXT NOT NULL,
    prenom      TEXT NOT NULL,
    profession  TEXT,
    grade       TEXT,
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (profession IS NOT NULL OR grade IS NOT NULL)
);

CREATE TABLE habilitation (
    id           TEXT PRIMARY KEY,
    fonction     TEXT NOT NULL,
    attribution  TEXT,
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE signature (
    autorisation_id   TEXT PRIMARY KEY REFERENCES autorisation(id),
    personne_id       TEXT NOT NULL REFERENCES personne(id),
    habilitation_id   TEXT NOT NULL REFERENCES habilitation(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE ampliation (
    id     TEXT PRIMARY KEY,
    label  TEXT NOT NULL,
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE autorisation_ampliation (
    autorisation_id   TEXT NOT NULL REFERENCES autorisation(id),
    ampliation_id     TEXT NOT NULL REFERENCES ampliation(id),
    structure         TEXT NOT NULL,
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (autorisation_id, ampliation_id)
);

CREATE TABLE agent (
    id             TEXT PRIMARY KEY,
    nom            TEXT NOT NULL,
    prenom         TEXT NOT NULL,
    telephone      TEXT NOT NULL UNIQUE,
    statut_agent   TEXT NOT NULL,
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    local_updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE enregistrement (
    id                        TEXT PRIMARY KEY,
    datetime_enregistrement   TEXT NOT NULL,
    autorisation_id           TEXT NOT NULL UNIQUE REFERENCES autorisation(id),
    agent_id                  TEXT NOT NULL REFERENCES agent(id),
    poste_id                  TEXT NOT NULL REFERENCES poste(id),
    sync_status       TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending','synced','error')),
    local_created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================================
-- INDEX utiles en local
-- ============================================================================

CREATE INDEX idx_demandeur_sync ON demandeur(sync_status);
CREATE INDEX idx_statut_demandeur_autre_sync ON statut_demandeur_autre(sync_status);
CREATE INDEX idx_demande_sync ON demande(sync_status);
CREATE INDEX idx_manifestation_sync ON manifestation(sync_status);
CREATE INDEX idx_genre_autre_sync ON genre_autre(sync_status);
CREATE INDEX idx_type_manifestation_autre_sync ON type_manifestation_autre(sync_status);
CREATE INDEX idx_periodicite_autre_sync ON periodicite_autre(sync_status);
CREATE INDEX idx_dimension_autre_sync ON dimension_autre(sync_status);
CREATE INDEX idx_type_espace_autre_sync ON type_espace_autre(sync_status);
CREATE INDEX idx_autorisation_sync ON autorisation(sync_status);
CREATE INDEX idx_personne_sync ON personne(sync_status);
CREATE INDEX idx_habilitation_sync ON habilitation(sync_status);
CREATE INDEX idx_signature_sync ON signature(sync_status);
CREATE INDEX idx_agent_sync ON agent(sync_status);
CREATE INDEX idx_ampliation_sync ON ampliation(sync_status);
CREATE INDEX idx_enregistrement_sync ON enregistrement(sync_status);
CREATE INDEX idx_poste_sync ON poste(sync_status);

CREATE INDEX idx_demande_demandeur ON demande(demandeur_id);
CREATE INDEX idx_autorisation_demande ON autorisation(demande_id);
CREATE INDEX idx_signature_personne ON signature(personne_id);
CREATE INDEX idx_signature_habilitation ON signature(habilitation_id);
CREATE INDEX idx_enregistrement_agent ON enregistrement(agent_id);
